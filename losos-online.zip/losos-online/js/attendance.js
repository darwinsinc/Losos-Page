/* ============================================================
   ŁOSOS SP · Asistencia: control diario, horas trabajadas y exportación a Excel (Cierre Mensual).
   ============================================================ */

// Attendance Control Logic with Mandatory Area Filter
function onAttendanceFilterChange() {
    currentSelectedMonth = parseInt(document.getElementById('select-month').value);
    renderAttendanceTable();
    updateProductionAssistanceMenu();
    renderProductionSupport();
}
function getDaysInMonth(year, month) {
    return new Date(year, month + 1, 0).getDate();
}

function renderAttendanceTable() {
    const areaSelectEl = document.getElementById('select-area-asistencia');
    if (!areaSelectEl) return;
    const selectedArea = areaSelectEl.value;
    const thead = document.getElementById('attendance-thead');
    const tbody = document.getElementById('attendance-tbody');
    const promptState = document.getElementById('empty-state-asistencia-prompt');
    const noneState = document.getElementById('empty-state-asistencia-none');
    
    thead.innerHTML = '';
    tbody.innerHTML = '';

    // Check if area is selected
    if (!selectedArea) {
        promptState.classList.remove('hidden');
        promptState.classList.add('flex');
        noneState.classList.add('hidden');
        noneState.classList.remove('flex');
        return;
    } else {
        promptState.classList.add('hidden');
        promptState.classList.remove('flex');
    }

    const daysCount = getDaysInMonth(currentYear, currentSelectedMonth);
    const activeEmployeesInArea = employees.filter(e => e.estado === 'Activo' && e.area === selectedArea);

    if (activeEmployeesInArea.length === 0) {
        noneState.classList.remove('hidden');
        noneState.classList.add('flex');
        return;
    } else {
        noneState.classList.add('hidden');
        noneState.classList.remove('flex');
    }

    // Build Header Row with 31 days
    let headerTr = `
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-bold text-slate-600 uppercase tracking-wider sticky left-0 bg-slate-100 z-10 min-w-[200px]">Colaborador / Día</th>
            `;
    for (let d = 1; d <= daysCount; d++) {
        headerTr += `<th class="px-2 py-3 text-center text-xs font-bold text-slate-700 w-10">${d}</th>`;
    }
    for (let d = daysCount + 1; d <= 31; d++) {
        headerTr += `<th class="px-2 py-3 text-center text-xs font-bold text-slate-300 w-10 opacity-40">${d}</th>`;
    }
    headerTr += `</tr>`;
    thead.innerHTML = headerTr;

    const monthKey = `${currentYear}-${currentSelectedMonth}`;
    if (!attendanceData[monthKey]) {
        attendanceData[monthKey] = {};
    }

    // Build Body Rows
    activeEmployeesInArea.forEach(emp => {
        if (!attendanceData[monthKey][emp.id]) {
            attendanceData[monthKey][emp.id] = {};
        }

        let row = document.createElement('tr');
        row.className = "hover:bg-slate-50 transition-colors";
        
        let htmlContent = `
                    <td class="px-4 py-3 whitespace-nowrap sticky left-0 bg-white z-10 border-r border-slate-200">
                        <div class="font-bold text-slate-900">${emp.nombre} ${emp.apellido}</div>
                        <div class="text-[11px] text-slate-500 flex gap-2">
                            <span>ID: ${emp.id}</span>
                            <span>•</span>
                            <span class="uppercase font-semibold text-primary-600">${emp.agencia}</span>
                            <span class="ml-2 text-emerald-700 font-bold">${getEmployeeMonthHours(emp.id, monthKey)} h</span>
                        </div>
                    </td>
                `;

        for (let d = 1; d <= 31; d++) {
            if (d <= daysCount) {
                const status = attendanceData[monthKey][emp.id][d] || '';
                let badgeClass = 'bg-slate-100 text-slate-400 hover:bg-slate-200';
                if (status === 'X') badgeClass = 'bg-emerald-600 text-white font-bold shadow-sm';
                if (status === 'O') badgeClass = 'bg-red-600 text-white font-bold shadow-sm';
                if (status === 'U') badgeClass = 'bg-blue-600 text-white font-bold shadow-sm';
                const hours = getWorkHours(emp.id, monthKey, d);
                htmlContent += `
                            <td class="px-1 py-2 text-center whitespace-nowrap">
                                <button type="button" data-attendance-button="1" data-employee-id="${String(emp.id).replace(/&/g,'&amp;').replace(/"/g,'&quot;')}" data-day="${d}"
                                    class="attendance-status w-8 h-8 rounded-lg text-xs transition-all inline-flex items-center justify-center ${badgeClass}"
                                    title="Cambiar estado: X presente · O ausente · U vacaciones · vacío para limpiar" aria-label="Asistencia de ${emp.nombre} ${emp.apellido}, día ${d}">
                                    ${status || '-'}
                                </button>
                                <input type="number" min="0" max="24" step="0.5" value="${hours}"
                                    ${status !== 'X' ? 'disabled' : ''}
                                    onchange="setWorkHours('${emp.id}', ${d}, this.value)"
                                    class="ml-1 w-12 h-7 text-center text-[10px] border border-slate-300 rounded-md ${status === 'X' ? 'bg-white' : 'bg-slate-100 text-slate-400'}"
                                    title="Horas trabajadas (por defecto 12)">
                            </td>
                        `;
            } else {
                htmlContent += `<td class="px-1 py-2 text-center bg-slate-50/50 text-slate-300">-</td>`;
            }
        }

        row.innerHTML = htmlContent;
        tbody.appendChild(row);
    });
}

// Control aislado por trabajador y día.
const attendanceActionStamp = new Map();
function cycleAttendance(empId, day) {
    const monthKey = `${currentYear}-${currentSelectedMonth}`;
    attendanceData[monthKey] ||= {};
    attendanceData[monthKey][empId] ||= {};
    const actionKey = `${monthKey}|${String(empId)}|${day}`;
    const now = performance.now();
    if (now - (attendanceActionStamp.get(actionKey) || -Infinity) < 260) return;
    attendanceActionStamp.set(actionKey, now);
    const current = attendanceData[monthKey][empId][day] || '';
    const next = current === '' ? 'X' : current === 'X' ? 'O' : current === 'O' ? 'U' : '';
    if (next) {
        attendanceData[monthKey][empId][day] = next;
        workHoursData[monthKey] ||= {};
        workHoursData[monthKey][empId] ||= {};
        workHoursData[monthKey][empId][day] = next === 'X' ? 12 : 0;
    } else {
        delete attendanceData[monthKey][empId][day];
        if (workHoursData?.[monthKey]?.[empId]) delete workHoursData[monthKey][empId][day];
    }
    saveData();
    renderAttendanceTable();
    if (typeof renderLiveOperations === 'function') renderLiveOperations();
    if (typeof renderScheduleSupportBanner === 'function') renderScheduleSupportBanner();
}
function setupAttendanceInteractions() {
    const tbody = document.getElementById('attendance-tbody');
    if (!tbody || tbody.dataset.attendanceBound === '1') return;
    tbody.dataset.attendanceBound = '1';
    tbody.addEventListener('click', event => {
        const button = event.target.closest('[data-attendance-button="1"]');
        if (!button || !tbody.contains(button)) return;
        event.preventDefault();
        event.stopPropagation();
        cycleAttendance(button.dataset.employeeId, Number(button.dataset.day));
    }, true);
}

function exportAttendanceToExcel() {
    if (typeof XLSX === 'undefined') {
        showNotification('No se pudo cargar el exportador de Excel. Comprueba tu conexión e inténtalo de nuevo.', 'error');
        return;
    }

    const area = document.getElementById('select-area-asistencia')?.value || '';
    if (!area) {
        showNotification('Selecciona un área antes de descargar el control.', 'error');
        return;
    }

    const monthKey = `${currentYear}-${currentSelectedMonth}`;
    const monthName = I18N_MONTHS_ES[currentSelectedMonth] || 'Mes';
    const workers = employees
        .filter(emp => emp.estado === 'Activo' && emp.area === area)
        .slice()
        .sort((a,b) => {
            const last = (a.apellido || '').localeCompare((b.apellido || ''), 'es', { sensitivity: 'base' });
            return last || (a.nombre || '').localeCompare((b.nombre || ''), 'es', { sensitivity: 'base' });
        });

    const summaryRows = workers.map(emp => {
        const attendance = attendanceData?.[monthKey]?.[emp.id] || {};
        const daysWorked = Object.keys(attendance).reduce((count, day) => count + (attendance[day] === 'X' ? 1 : 0), 0);
        const hoursWorked = getEmployeeMonthHours(emp.id, monthKey);
        return [emp.apellido || '', emp.nombre || '', emp.area || area, emp.agencia || '', daysWorked, Number(hoursWorked.toFixed(2))];
    });

    const detailRows = [];
    const daysCount = getDaysInMonth(currentYear, currentSelectedMonth);
    workers.forEach(emp => {
        const attendance = attendanceData?.[monthKey]?.[emp.id] || {};
        const hours = workHoursData?.[monthKey]?.[emp.id] || {};
        for (let day = 1; day <= daysCount; day++) {
            const status = attendance[day] || '';
            detailRows.push([
                day,
                `${String(day).padStart(2,'0')}/${String(currentSelectedMonth + 1).padStart(2,'0')}/${currentYear}`,
                emp.apellido || '',
                emp.nombre || '',
                emp.agencia || '',
                status || '—',
                status === 'X' ? Number((Number(hours[day] || 0)).toFixed(2)) : 0
            ]);
        }
    });

    const wb = XLSX.utils.book_new();

    const summaryAoa = [
        ['ŁOSOS SP Z O. O. · CIERRE MENSUAL'],
        [`CONTROL DE ASISTENCIA · ${area}`, `${monthName.toUpperCase()} ${currentYear}`],
        [''],
        ['APELLIDO', 'NOMBRE', 'ÁREA', 'AGENCIA', 'DÍAS TRABAJADOS', 'HORAS REALIZADAS'],
        ...summaryRows,
        [''],
        ['TOTAL DEL ÁREA', '', '', '',
            summaryRows.reduce((sum, row) => sum + Number(row[4] || 0), 0),
            Number(summaryRows.reduce((sum, row) => sum + Number(row[5] || 0), 0).toFixed(2))
        ]
    ];

    const wsSummary = XLSX.utils.aoa_to_sheet(summaryAoa);
    wsSummary['!merges'] = [
        { s: { r: 0, c: 0 }, e: { r: 0, c: 5 } },
        { s: { r: 1, c: 0 }, e: { r: 1, c: 3 } }
    ];
    wsSummary['!cols'] = [
        { wch: 24 }, { wch: 24 }, { wch: 21 }, { wch: 20 }, { wch: 18 }, { wch: 18 }
    ];
    wsSummary['!rows'] = [{ hpt: 28 }, { hpt: 22 }, { hpt: 8 }, { hpt: 24 }];
    wsSummary['!autofilter'] = { ref: `A4:F${Math.max(4, 4 + summaryRows.length)}` };
    wsSummary['!freeze'] = { xSplit: 0, ySplit: 4 };

    const detailAoa = [
        ['ŁOSOS SP Z O. O. · DETALLE DIARIO'],
        [`ÁREA: ${area}`, `MES: ${monthName.toUpperCase()} ${currentYear}`],
        [''],
        ['DÍA', 'FECHA', 'APELLIDO', 'NOMBRE', 'AGENCIA', 'ESTADO', 'HORAS'],
        ...detailRows
    ];
    const wsDetail = XLSX.utils.aoa_to_sheet(detailAoa);
    wsDetail['!merges'] = [
        { s: { r: 0, c: 0 }, e: { r: 0, c: 6 } },
        { s: { r: 1, c: 0 }, e: { r: 1, c: 2 } }
    ];
    wsDetail['!cols'] = [
        { wch: 8 }, { wch: 14 }, { wch: 24 }, { wch: 24 }, { wch: 20 }, { wch: 12 }, { wch: 12 }
    ];
    wsDetail['!rows'] = [{ hpt: 28 }, { hpt: 22 }, { hpt: 8 }, { hpt: 24 }];
    wsDetail['!autofilter'] = { ref: `A4:G${Math.max(4, 4 + detailRows.length)}` };
    wsDetail['!freeze'] = { xSplit: 0, ySplit: 4 };

    // Hoja adicional para Norma, cuando existan registros en el mes seleccionado.
    const normaRows = [];
    Object.values(normaRecords || {}).forEach(records => {
        (Array.isArray(records) ? records : []).forEach(record => {
            if (!record || !record.date) return;
            const recordDate = new Date(record.date + 'T00:00:00');
            if (recordDate.getFullYear() !== currentYear || recordDate.getMonth() !== currentSelectedMonth) return;
            const emp = employees.find(e => String(e.id) === String(record.workerId));
            if (!emp || emp.area !== 'PRODUCCIÓN') return;
            normaRows.push([
                record.date,
                emp.apellido || '',
                emp.nombre || '',
                record.reason || '',
                record.start || '',
                record.end || '',
                Number(record.hours || 0)
            ]);
        });
    });
    normaRows.sort((a,b) => String(a[0]).localeCompare(String(b[0])) || String(a[1]).localeCompare(String(b[1])));
    const normaAoa = [
        ['ŁOSOS SP Z O. O. · NORMA'],
        [`REGISTROS DE NORMA · ${monthName.toUpperCase()} ${currentYear}`],
        [''],
        ['FECHA', 'APELLIDO', 'NOMBRE', 'MOTIVO', 'DESDE', 'HASTA', 'HORAS'],
        ...normaRows
    ];
    const wsNorma = XLSX.utils.aoa_to_sheet(normaAoa);
    wsNorma['!merges'] = [{ s:{r:0,c:0}, e:{r:0,c:6} }];
    wsNorma['!cols'] = [{wch:14},{wch:24},{wch:24},{wch:14},{wch:10},{wch:10},{wch:12}];
    wsNorma['!rows'] = [{hpt:28},{hpt:22},{hpt:8},{hpt:24}];
    wsNorma['!autofilter'] = {ref:`A4:G${Math.max(4,4+normaRows.length)}`};
    wsNorma['!freeze'] = {xSplit:0,ySplit:4};

    // Estilo básico de celdas. Si la versión CE del exportador no aplica estilos,
    // la estructura, anchos, filtros y congelación siguen manteniendo el informe ordenado.
    [wsSummary, wsDetail, wsNorma].forEach(ws => {
        if (ws['A1']) ws['A1'].s = { font:{bold:true,sz:16,color:{rgb:'FFFFFF'}}, fill:{fgColor:{rgb:'111827'}}, alignment:{horizontal:'center',vertical:'center'} };
        const lastCol = ws === wsSummary ? ['A','B','C','D','E','F'] : ['A','B','C','D','E','F','G'];
        lastCol.forEach(col => {
            const head = ws[`${col}4`];
            if (head) head.s = { font:{bold:true,color:{rgb:'FFFFFF'}}, fill:{fgColor:{rgb:'334155'}}, alignment:{horizontal:'center',vertical:'center'} };
        });
    });

    XLSX.utils.book_append_sheet(wb, wsSummary, 'Cierre Mensual');
    XLSX.utils.book_append_sheet(wb, wsDetail, 'Detalle Diario');
    XLSX.utils.book_append_sheet(wb, wsNorma, 'NORMA');

    const fileMonth = String(currentSelectedMonth + 1).padStart(2, '0');
    const safeArea = area.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    XLSX.writeFile(wb, `cierre-mensual-${safeArea}-${currentYear}-${fileMonth}.xlsx`, { compression: true });
    showNotification('Cierre Mensual generado correctamente.', 'success');
}

function getWorkHours(empId, monthKey, day) {
    return Number(workHoursData?.[monthKey]?.[empId]?.[day] ?? 0);
}

function getEmployeeMonthHours(empId, monthKey) {
    const days = workHoursData?.[monthKey]?.[empId] || {};
    return Object.values(days).reduce((sum, h) => sum + Number(h || 0), 0);
}

function setWorkHours(empId, day, value) {
    const monthKey = `${currentYear}-${currentSelectedMonth}`;
    const status = attendanceData?.[monthKey]?.[empId]?.[day] || '';
    if (status !== 'X') {
        showNotification('Las horas solo se pueden registrar para días con asistencia (X).', 'error');
        renderAttendanceTable();
        return;
    }
    const hours = Math.max(0, Math.min(24, Number(value) || 0));
    if (!workHoursData[monthKey]) workHoursData[monthKey] = {};
    if (!workHoursData[monthKey][empId]) workHoursData[monthKey][empId] = {};
    workHoursData[monthKey][empId][day] = hours;
    saveData();
    renderAttendanceTable();
}
