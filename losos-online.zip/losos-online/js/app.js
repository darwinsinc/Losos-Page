/* ============================================================
   ŁOSOS SP · Arranque: guarda el estado al salir e inicializa cada página según los elementos que contiene.
   ============================================================ */

window.addEventListener('beforeunload', () => { try { saveData(); } catch(e) {} });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') { try { saveData(); } catch(e) {} } });
window.addEventListener('pagehide', () => { try { saveData(); } catch(e) {} });

// Todas las páginas cargan los mismos scripts; runPageInit() inicializa
// únicamente las secciones que la página actual realmente contiene.
let __lososLiveInterval = null;
function runPageInit() {
    updateLanguageSpecificUI();
    if (__lososLiveInterval) { clearInterval(__lososLiveInterval); __lososLiveInterval = null; }
    if (document.getElementById('employees-tbody')) renderRegistroTable();
    if (document.getElementById('history-tbody')) renderHistoryTable();
    setupEmployeeForm();
    setupEditEmployeeForm();
    if (document.getElementById('select-area-asistencia')) {
        renderAttendanceTable();
        setupAttendanceInteractions();
        updateProductionAssistanceMenu();
        renderProductionSupport();
        ['production-start-time','production-end-time'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('input', updateNormaDurationPreview);
            if (el) el.addEventListener('change', updateNormaDurationPreview);
        });
        updateNormaDurationPreview();
        const awariaReason = document.getElementById('awaria-reason');
        const awariaDate = document.getElementById('awaria-date');
        if (awariaReason) awariaReason.addEventListener('change', renderAwariaWorkerList);
        if (awariaDate) awariaDate.addEventListener('change', renderAwariaWorkerList);
    }
    if (document.getElementById('norma-history-tbody')) {
        populateNormaHistoryFilters();
        renderNormaHistory();
        ['norma-edit-start','norma-edit-end'].forEach(id => {
            const el = document.getElementById(id);
            if (el) { el.addEventListener('input', updateNormaEditPreview); el.addEventListener('change', updateNormaEditPreview); }
        });
    }
    if (document.getElementById('schedule-area')) {
        loadScheduleRequirements();
        setupShiftDropZones();
    }
    if (document.getElementById('live-area-counters')) {
        renderLiveOperations(); renderNormaRankingBanners(); renderScheduleSupportBanner();
        __lososLiveInterval = setInterval(()=>{ renderLiveOperations(); renderNormaRankingBanners(); renderScheduleSupportBanner(); }, 1000);
    }
    showAutoSaveIndicator('Cambios guardados');
    applyIconMapping();
}
window.onload = runPageInit;
