/* ============================================================
   ŁOSOS SP · Estado global de la aplicación y persistencia en localStorage.
   Todas las páginas comparten las mismas claves, por lo que quedan conectadas entre sí.
   ============================================================ */

// ============================================================
// PERSISTENCIA AVANZADA: localStorage + estado embebido en HTML
// (Se declara aquí arriba porque currentLanguage y otras variables
//  la necesitan desde el principio del script)
// ============================================================
// Todas las páginas (Personal, Coordinador, Jefe) leen y escriben las
// mismas claves de localStorage, por lo que quedan siempre conectadas
// entre sí: lo que se registra en una pantalla aparece en las demás.
const loadState = (storageKey, fallback) => {
    try {
        const stored = localStorage.getItem(storageKey);
        return stored ? JSON.parse(stored) : fallback;
    } catch (e) { return fallback; }
};
// State management with localStorage persistence
let employees = loadState('corphr_employees', [
    { id: '101', apellido: 'Gómez Ruiz', nombre: 'Carlos Alberto', agencia: 'JOBMIRO', fecha: '2026-01-10', area: 'PRODUCCIÓN', estado: 'Activo', cargo: '' },
    { id: '102', apellido: 'Pérez Silva', nombre: 'María Fernanda', agencia: 'SREBNA', fecha: '2026-02-15', area: 'ETIQUETA', estado: 'Activo', cargo: '' },
    { id: '103', apellido: 'López Torres', nombre: 'Jorge Luis', agencia: 'TIWAS', fecha: '2026-03-01', area: 'DESCONGELACIÓN', estado: 'Activo', cargo: '' }
]);

let historyLog = loadState('corphr_history', []);
let attendanceData = loadState('corphr_attendance', {});
// Migración: se elimina definitivamente el estado F (incapacidad).
Object.values(attendanceData || {}).forEach(month => Object.values(month || {}).forEach(days => {
    Object.keys(days || {}).forEach(day => { if (days[day] === 'F') delete days[day]; });
}));
let workHoursData = loadState('corphr_work_hours', {});
let shiftSchedule = loadState('corphr_shift_schedule', {});
let normaRecords = loadState('corphr_norma_records', {});
let normaScores = loadState('corphr_norma_scores', {});
let productionSupport = loadState('corphr_production_support', {});
let awariaRecords = loadState('corphr_awaria_records', {});

// Compatibilidad: antes los apoyos se guardaban como IDs; ahora cada apoyo
// conserva también su horario de inicio y fin.
Object.keys(productionSupport || {}).forEach(date => {
    const entries = Array.isArray(productionSupport[date]) ? productionSupport[date] : [];
    productionSupport[date] = entries.map(item => {
        if (item && typeof item === 'object') return { workerId: item.workerId ?? item.id, start: item.start || '', end: item.end || '' };
        return { workerId: item, start: '', end: '' };
    }).filter(item => item.workerId != null && String(item.workerId) !== '');
});

// Compatibilidad con trabajadores guardados antes de incorporar el campo Cargo.
employees = employees.map(emp => ({
    ...emp,
    agencia: (emp.agencia || '').toUpperCase(),
    area: (emp.area || '').toUpperCase(),
    cargo: emp.cargo || '',
    estado: emp.estado || 'Activo',
    modalidadIngreso: emp.modalidadIngreso || 'registrar'
}));

// Mantiene una estructura estable para los 3 turnos.
Object.values(shiftSchedule).forEach(schedule => {
    if (!schedule || typeof schedule !== 'object') return;
    ['turno1','turno2','turno3'].forEach(shift => {
        schedule[shift] = Array.isArray(schedule[shift]) ? [...new Set(schedule[shift])] : [];
    });
    schedule.requirements = {
        turno1: Math.max(0, Number(schedule.requirements?.turno1 || 0)),
        turno2: Math.max(0, Number(schedule.requirements?.turno2 || 0)),
        turno3: Math.max(0, Number(schedule.requirements?.turno3 || 0))
    };
});

let currentSelectedMonth = new Date().getMonth(); // 0-11
const currentYear = new Date().getFullYear();

// Cada página (Personal / Coordinador / Jefe) solo contiene un subconjunto
// de estos controles, por lo que cada acceso se blinda con una comprobación.
const scheduleMonthInit = document.getElementById('schedule-month');
if (scheduleMonthInit) scheduleMonthInit.value = new Date().getMonth();
const scheduleWeekInit = document.getElementById('schedule-week');
if (scheduleWeekInit) scheduleWeekInit.value = Math.min(5, Math.floor((new Date().getDate() - 1) / 7) + 1);

// Set Month selector initial value (pestaña de Asistencia)
const selectMonthInit = document.getElementById('select-month');
if (selectMonthInit) selectMonthInit.value = currentSelectedMonth;

function saveData() {
    try {
        localStorage.setItem('corphr_employees', JSON.stringify(employees));
        localStorage.setItem('corphr_history', JSON.stringify(historyLog));
        localStorage.setItem('corphr_attendance', JSON.stringify(attendanceData));
        localStorage.setItem('corphr_work_hours', JSON.stringify(workHoursData));
        localStorage.setItem('corphr_shift_schedule', JSON.stringify(shiftSchedule));
        localStorage.setItem('corphr_norma_records', JSON.stringify(normaRecords));
        localStorage.setItem('corphr_norma_scores', JSON.stringify(normaScores));
        localStorage.setItem('corphr_production_support', JSON.stringify(productionSupport));
        localStorage.setItem('corphr_awaria_records', JSON.stringify(awariaRecords));
        localStorage.setItem('corphr_language', currentLanguage);
        showAutoSaveIndicator();
    } catch (e) {
        console.error('Error saving to localStorage', e);
        showNotification('No se pudieron guardar todos los datos localmente.', 'error');
    }
}
