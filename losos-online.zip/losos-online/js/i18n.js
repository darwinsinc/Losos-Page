/* ============================================================
   ŁOSOS SP · Motor de idioma: traduce la interfaz y el contenido dinámico (Español / Polski).
   ============================================================ */

let currentLanguage = localStorage.getItem('corphr_language') || 'es';
const i18nOriginalText = new WeakMap();
const i18nOriginalAttrs = new WeakMap();

function translateText(value, lang) {
    if (lang === 'es' || !value) return value;
    if (I18N_PL[value] !== undefined) return I18N_PL[value];
    let result = value;
    Object.entries(I18N_PL)
        .sort((a,b) => b[0].length - a[0].length)
        .forEach(([es, pl]) => {
            result = result.split(es).join(pl);
        });
    Object.entries(I18N_WORDS_PL)
        .sort((a,b) => b[0].length - a[0].length)
        .forEach(([es, pl]) => {
            result = result.replace(new RegExp(`\\b${es.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')}\\b`, 'g'), pl);
        });
    return result;
}

function translateElementTree(root = document.body) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) {
        const node = walker.currentNode;
        if (!node.nodeValue.trim() || ['SCRIPT','STYLE'].includes(node.parentElement?.tagName)) continue;
        nodes.push(node);
    }
    nodes.forEach(node => {
        if (!i18nOriginalText.has(node)) i18nOriginalText.set(node, node.nodeValue);
        node.nodeValue = translateText(i18nOriginalText.get(node), currentLanguage);
    });

    root.querySelectorAll?.('*').forEach(el => {
        ['title','placeholder','aria-label'].forEach(attr => {
            if (!el.hasAttribute(attr)) return;
            let originals = i18nOriginalAttrs.get(el);
            if (!originals) { originals = {}; i18nOriginalAttrs.set(el, originals); }
            if (originals[attr] === undefined) originals[attr] = el.getAttribute(attr);
            el.setAttribute(attr, translateText(originals[attr], currentLanguage));
        });
    });
}

function updateLanguageSpecificUI() {
    const dateEl = document.getElementById('current-date');
    if (dateEl) {
        const locale = currentLanguage === 'pl' ? 'pl-PL' : 'es-ES';
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const text = new Date().toLocaleDateString(locale, dateOptions);
        dateEl.innerHTML = `<i class="fa-regular fa-calendar text-primary-600 mr-1.5"></i> ${text.charAt(0).toUpperCase() + text.slice(1)}`;
    }
    document.documentElement.lang = currentLanguage;
    const selector = document.getElementById('language-selector');
    if (selector) selector.value = currentLanguage;
    translateElementTree(document.body);
}

function setLanguage(lang) {
    currentLanguage = lang === 'pl' ? 'pl' : 'es';
    localStorage.setItem('corphr_language', currentLanguage);
    updateLanguageSpecificUI();
}

// Traduce también contenido dinámico generado por las funciones de renderizado.
let applyingTranslation = false;
const i18nObserver = new MutationObserver(mutations => {
    if (currentLanguage !== 'pl' || applyingTranslation) return;
    applyingTranslation = true;
    mutations.forEach(m => {
        m.addedNodes.forEach(node => {
            if (node.nodeType === Node.ELEMENT_NODE) translateElementTree(node);
            else if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim()) {
                if (!i18nOriginalText.has(node)) i18nOriginalText.set(node, node.nodeValue);
                node.nodeValue = translateText(i18nOriginalText.get(node), currentLanguage);
            }
        });
    });
    applyingTranslation = false;
});
i18nObserver.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['title','placeholder','aria-label'] });
