/* ============================================================
   ŁOSOS SP · Personal: nómina, alta / edición / baja de trabajadores e historial de bajas.
   ============================================================ */

// Render Nómina Table
function renderRegistroTable() {
    const tbody = document.getElementById('employees-tbody');
    if (!tbody) return;
    const emptyState = document.getElementById('empty-state-registro');
    const countBadge = document.getElementById('total-workers');
    const searchInput = document.getElementById('employee-search');
    const clearButton = document.getElementById('clear-employee-search');
    const query = (searchInput?.value || '').trim().toLowerCase();

    tbody.innerHTML = '';

    const activeEmployees = employees.filter(emp => String(emp.estado || '').toLowerCase() === 'activo');
    const filteredEmployees = activeEmployees
        .filter(emp => {
            if (!query) return true;
            const searchable = [emp.id, emp.nombre, emp.apellido, emp.agencia, emp.area, emp.cargo, emp.estado, emp.modalidadIngreso]
                .filter(Boolean).join(' ').toLowerCase();
            return searchable.includes(query);
        })
        .slice()
        .sort((a, b) => {
            const first = (a.nombre || '').localeCompare(b.nombre || '', 'es', { sensitivity: 'base' });
            if (first !== 0) return first;
            return (a.apellido || '').localeCompare(b.apellido || '', 'es', { sensitivity: 'base' });
        });

    countBadge.textContent = query
        ? `${filteredEmployees.length} de ${activeEmployees.length} Trabajadores activos`
        : `${activeEmployees.length} Trabajadores activos`;
    if (clearButton) clearButton.classList.toggle('hidden', !query);

    if (filteredEmployees.length === 0) {
        emptyState.classList.remove('hidden');
        emptyState.classList.add('flex');
        emptyState.querySelector('h3')?.replaceChildren(document.createTextNode(query ? 'Sin resultados' : 'No hay trabajadores registrados'));
        emptyState.querySelector('p')?.replaceChildren(document.createTextNode(query ? 'No se encontró ningún trabajador con esa búsqueda.' : 'Agrega trabajadores para comenzar.'));
    } else {
        emptyState.classList.add('hidden');
        emptyState.classList.remove('flex');

        filteredEmployees.forEach(emp => {
            const row = document.createElement('tr');
            row.className = "hover:bg-slate-50/80 transition-colors";
            row.innerHTML = `
                        <td class="px-6 py-4 whitespace-nowrap font-bold text-slate-900">${emp.id}</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="font-semibold text-slate-800">${escapeHtml(emp.nombre || '')} ${escapeHtml(emp.apellido || '')}</div>
                            ${emp.modalidadIngreso === 'unirme' ? '<div class="text-[11px] font-bold uppercase tracking-wide text-primary-600 mt-0.5">Unido</div>' : ''}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap"><span class="uppercase text-xs font-bold px-2.5 py-1 bg-slate-100 rounded-md text-slate-700">${emp.agencia}</span></td>
                        <td class="px-6 py-4 whitespace-nowrap text-slate-600 font-medium">${formatTableDate(emp.fecha)}</td>
                        <td class="px-6 py-4 whitespace-nowrap"><span class="uppercase text-xs font-medium px-2.5 py-1 bg-primary-50 text-primary-700 rounded-md">${emp.area}</span></td>
                        <td class="px-7 py-4 min-w-[190px]">
                            ${emp.cargo ? `<span class="cargo-pill">${emp.cargo}</span>` : '<span class="cargo-empty">—</span>'}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                                Activo
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right">
                            <button onclick="openEditEmployee('${emp.id}')" class="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-primary-50 hover:text-primary-700 transition-colors inline-flex items-center justify-center mr-1" title="Editar datos del trabajador">
                                <i class="fa-solid fa-pencil text-sm"></i>
                            </button>
                            <button onclick="deleteEmployee('${emp.id}')" class="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 hover:bg-red-50 hover:text-red-600 transition-colors inline-flex items-center justify-center" title="Dar de baja / Eliminar">
                                <i class="fa-solid fa-trash-can text-sm"></i>
                            </button>
                        </td>
                    `;
            tbody.appendChild(row);
        });
    }
}

function clearEmployeeSearch() {
    const input = document.getElementById('employee-search');
    if (!input) return;
    input.value = '';
    input.focus();
    renderRegistroTable();
}

// Form Submission (solo existe en la página de Personal)
// La vinculación del evento se hace en una función reutilizable, invocada
// desde runPageInit() al cargar la página, con una bandera para no
// duplicar el listener si runPageInit() se ejecuta varias veces.
function setupEmployeeForm() {
    const form = document.getElementById('employee-form');
    if (!form || form.dataset.submitBound === '1') return;
    form.dataset.submitBound = '1';
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const modalidad = document.getElementById('emp-modalidad')?.value || 'registrar';
        const newEmp = {
            id: document.getElementById('emp-id').value.trim(),
            apellido: document.getElementById('emp-apellido').value.trim(),
            nombre: document.getElementById('emp-nombre').value.trim(),
            agencia: document.getElementById('emp-agencia').value,
            fecha: document.getElementById('emp-fecha').value,
            area: document.getElementById('emp-area').value,
            modalidadIngreso: modalidad,
            estado: 'Activo',
            cargo: ''
        };

        if (!newEmp.id || !newEmp.apellido || !newEmp.nombre || !newEmp.agencia || !newEmp.fecha || !newEmp.area) {
            showNotification('Completa todos los campos obligatorios.', 'error');
            return;
        }

        if (employees.some(emp => emp.id === newEmp.id)) {
            showNotification('El ID o Documento ya se encuentra registrado en el sistema.', 'error');
            return;
        }

        employees.push(newEmp);
        saveData();
        form.reset();
        renderRegistroTable();
        showNotification(modalidad === 'unirme' ? 'Te has unido correctamente y apareces como personal activo.' : 'Trabajador registrado y guardado automáticamente.', 'success');
    });
}

// Edit Employee
function openEditEmployee(empId) {
    const emp = employees.find(e => e.id === empId);
    if (!emp) return;
    document.getElementById('edit-emp-original-id').value = emp.id;
    document.getElementById('edit-emp-id').value = emp.id || '';
    document.getElementById('edit-emp-apellido').value = emp.apellido || '';
    document.getElementById('edit-emp-nombre').value = emp.nombre || '';
    document.getElementById('edit-emp-agencia').value = (emp.agencia || '').toUpperCase();
    document.getElementById('edit-emp-fecha').value = emp.fecha || '';
    document.getElementById('edit-emp-area').value = (emp.area || '').toUpperCase();
    document.getElementById('edit-emp-cargo').value = emp.cargo || '';
    const modal = document.getElementById('edit-employee-modal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeEditEmployee() {
    const modal = document.getElementById('edit-employee-modal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

// Igual que con employee-form: se vincula desde runPageInit() con bandera
// anti-duplicado.
function setupEditEmployeeForm() {
    const form = document.getElementById('edit-employee-form');
    if (!form || form.dataset.submitBound === '1') return;
    form.dataset.submitBound = '1';
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const originalId = document.getElementById('edit-emp-original-id').value;
        const index = employees.findIndex(e => e.id === originalId);
        if (index === -1) return showNotification('No se encontró el trabajador.', 'error');
        const newId = document.getElementById('edit-emp-id').value.trim();
        if (employees.some((emp, i) => i !== index && emp.id === newId)) {
            return showNotification('El ID o Documento ya se encuentra registrado en el sistema.', 'error');
        }
        const previousArea = employees[index].area;
        const newArea = document.getElementById('edit-emp-area').value.toUpperCase();
        employees[index] = {
            ...employees[index],
            id: newId,
            apellido: document.getElementById('edit-emp-apellido').value.trim(),
            nombre: document.getElementById('edit-emp-nombre').value.trim(),
            agencia: document.getElementById('edit-emp-agencia').value.toUpperCase(),
            fecha: document.getElementById('edit-emp-fecha').value,
            area: newArea,
            cargo: document.getElementById('edit-emp-cargo').value.trim()
        };

        if (previousArea !== newArea) {
            // Las asignaciones de horario están ligadas al área seleccionada.
            Object.values(shiftSchedule).forEach(schedule => {
                ['turno1','turno2','turno3'].forEach(shift => {
                    if (Array.isArray(schedule[shift])) schedule[shift] = schedule[shift].filter(id => id !== originalId && id !== newId);
                });
            });
        } else if (originalId !== newId) {
            Object.values(shiftSchedule).forEach(schedule => {
                ['turno1','turno2','turno3'].forEach(shift => {
                    if (Array.isArray(schedule[shift])) schedule[shift] = schedule[shift].map(id => id === originalId ? newId : id);
                });
            });
        }
        saveData();
        renderRegistroTable();
        if (typeof renderSchedule === 'function') renderSchedule();
        closeEditEmployee();
        showNotification('Datos del trabajador actualizados y guardados.', 'success');
    });
}

// Delete Employee
function deleteEmployee(empId) {
    const index = employees.findIndex(e => e.id === empId);
    if (index > -1) {
        const removedEmp = employees.splice(index, 1)[0];
        
        const now = new Date();
        const dateTimeStr = now.toLocaleDateString('es-ES') + ' a las ' + now.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        
        historyLog.unshift({
            ...removedEmp,
            deletedAt: dateTimeStr
        });

        saveData();
        renderRegistroTable();
        renderHistoryTable();
        showNotification(`Trabajador ${removedEmp.nombre} dado de baja. Datos actualizados.`, 'info');
    }
}

// Render History Table
function renderHistoryTable() {
    const tbody = document.getElementById('history-tbody');
    if (!tbody) return;
    const emptyState = document.getElementById('empty-state-history');
    const countBadge = document.getElementById('history-count');
    const navBadge = document.getElementById('history-badge');
    
    tbody.innerHTML = '';
    countBadge.textContent = `${historyLog.length} Registros`;
    navBadge.textContent = historyLog.length;

    if (historyLog.length === 0) {
        emptyState.classList.remove('hidden');
        emptyState.classList.add('flex');
    } else {
        emptyState.classList.add('hidden');
        emptyState.classList.remove('flex');
        
        historyLog.forEach((item, idx) => {
            const row = document.createElement('tr');
            row.className = "hover:bg-slate-50/80 transition-colors";
            row.innerHTML = `
                        <td class="px-6 py-4 whitespace-nowrap font-bold text-slate-900">${item.id}</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="font-semibold text-slate-800">${item.nombre}</div>
                            <div class="text-xs text-slate-500">${item.apellido}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap"><span class="uppercase text-xs font-bold px-2.5 py-1 bg-slate-100 rounded-md text-slate-700">${item.agencia}</span></td>
                        <td class="px-6 py-4 whitespace-nowrap"><span class="uppercase text-xs font-medium px-2.5 py-1 bg-slate-100 text-slate-700 rounded-md">${item.area}</span></td>
                        <td class="px-6 py-4 whitespace-nowrap text-xs font-semibold text-red-600 bg-red-50/50">
                            <i class="fa-regular fa-clock mr-1"></i> ${item.deletedAt}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right">
                            <button onclick="restoreEmployee(${idx})" class="text-xs font-bold bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 px-3 py-1.5 rounded-lg transition-colors border border-slate-200">
                                <i class="fa-solid fa-rotate-left mr-1"></i> Restaurar
                            </button>
                        </td>
                    `;
            tbody.appendChild(row);
        });
    }
}

function restoreEmployee(idx) {
    const restored = historyLog.splice(idx, 1)[0];
    delete restored.deletedAt;
    restored.estado = 'Activo';
    employees.push(restored);
    saveData();
    renderHistoryTable();
    renderRegistroTable();
    showNotification('Trabajador restaurado con éxito a la nómina activa.', 'success');
}
