/* ============================================================
   ŁOSOS SP · Sesión, perfiles y navegación entre páginas
   Se carga en el <head> de cada página para que la comprobación de
   acceso ocurra antes de pintar nada.

   Uso en las páginas protegidas:
     <script src="js/session.js" data-require-role="coordinador"></script>
   ============================================================ */

/* Guardia de modo online (se ejecuta primero) */
(function(){
  'use strict';
  try {
    document.documentElement.dataset.mode = 'online';
    window.addEventListener('online', function(){ document.documentElement.dataset.network='available'; });
    window.addEventListener('online', function(){ document.documentElement.dataset.network='online'; });
  } catch(e) {}
})();

const LOGIN_PAGE = 'index.html';
const SESSION_ROLE_KEY = 'losos_role';

/* Ir a otra página de la aplicación */
function navigate(page) {
    window.location.href = page;
}

/* Si el perfil de la sesión no coincide con el requerido, vuelve al inicio */
function roleGuard(requiredRole) {
    try {
        if (sessionStorage.getItem(SESSION_ROLE_KEY) !== requiredRole) {
            window.location.replace(LOGIN_PAGE);
            return false;
        }
    } catch (e) {}
    return true;
}

/* Elegir perfil en la portada (index.html) y entrar a su página */
function selectProfile(role, page) {
    sessionStorage.setItem(SESSION_ROLE_KEY, role);
    navigate(page);
}

/* Cerrar sesión: borra el perfil y vuelve a la portada */
function logout() {
    try { sessionStorage.removeItem(SESSION_ROLE_KEY); } catch (e) {}
    window.location.replace(LOGIN_PAGE);
}

/* Comprobación automática según el atributo data-require-role del <script> */
(function () {
    const script = document.currentScript;
    const required = script && script.dataset.requireRole;
    if (required) roleGuard(required);
})();
