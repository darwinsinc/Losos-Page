/* ============================================================
   ŁOSOS SP · Horarios: turnos, requerimientos, panel en vivo, arrastrar y soltar y descarga CSV.
   ============================================================ */

function shuffleArray(arr) {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
}

function getScheduleSelection() {
    const month = parseInt(document.getElementById('schedule-month').value);
    const week = parseInt(document.getElementById('schedule-week').value);
    const year = currentYear;
    const startDay = (week - 1) * 7 + 1;
    const daysInMonth = getDaysInMonth(year, month);
    if (startDay > daysInMonth) return null;
    const endDay = Math.min(startDay + 6, daysInMonth);
    return { year, month, week, startDay, endDay };
}

function getScheduleKey() {
    const area = document.getElementById('schedule-area').value;
    const selection = getScheduleSelection();
    return area && selection ? `${selection.year}-${selection.month}-W${selection.week}__${area}` : '';
}

function formatScheduleWeekLabel(selection) {
    if (!selection) return 'SEMANA NO DISPONIBLE';
    const monthName = new Date(selection.year, selection.month, 1)
        .toLocaleDateString('es-ES', { month: 'long' }).toUpperCase();
    return `${monthName} · SEMANA ${selection.week}`;
}

function updateScheduleWeekOptions() {
    const monthEl = document.getElementById('schedule-month');
    const weekSelect = document.getElementById('schedule-week');
    if (!monthEl || !weekSelect) return;
    const month = parseInt(monthEl.value);
    const daysInMonth = getDaysInMonth(currentYear, month);
    [...weekSelect.options].forEach((option, index) => {
        const startDay = index * 7 + 1;
        const endDay = Math.min(startDay + 6, daysInMonth);
        option.disabled = startDay > daysInMonth;
        option.textContent = `SEMANA ${index + 1}`;
    });
    const selected = getScheduleSelection();
    document.getElementById('schedule-week-range').textContent =
        selected ? formatScheduleWeekLabel(selected) : 'SEMANA NO DISPONIBLE';
}

function renderSchedule() {
    const areaEl = document.getElementById('schedule-area');
    if (!areaEl) return; // La sección de horarios solo existe en la página del Jefe
    const area = areaEl.value;
    const prompt = document.getElementById('schedule-prompt');
    const content = document.getElementById('schedule-content');
    updateScheduleWeekOptions();
    const selection = getScheduleSelection();
    if (!area || !selection) {
        prompt.classList.remove('hidden'); prompt.classList.add('flex');
        content.classList.add('hidden'); return;
    }

    prompt.classList.add('hidden'); prompt.classList.remove('flex');
    content.classList.remove('hidden');

    const active = employees.filter(e => e.estado === 'Activo' && e.area === area);
    const key = getScheduleKey();
    const schedule = shiftSchedule[key] || { turno1: [], turno2: [], turno3: [], requirements: {turno1:0,turno2:0,turno3:0} };
    ['turno1','turno2','turno3'].forEach(shift => {
        const tbody = document.getElementById(`${shift}-tbody`);
        const ids = schedule[shift] || [];
        const people = ids.map(id => employees.find(e => e.id === id)).filter(Boolean);
        tbody.innerHTML = people.length ? people.map(e => `<tr draggable="true" ondragstart="startShiftDrag(event, '${e.id}', '${shift}')" class="border-b border-slate-100 cursor-grab active:cursor-grabbing hover:bg-primary-50/50 transition-colors">
                        <td class="px-4 py-3 font-bold">${e.id}</td>
                        <td class="px-4 py-3 font-semibold"><i class="fa-solid fa-grip-vertical mr-2 text-slate-300"></i>${e.nombre} ${e.apellido}</td>
                        <td class="px-4 py-3">${e.agencia}</td>
                        <td class="px-4 py-3">${e.area}</td>
                    </tr>`).join('') :
            `<tr><td colspan="4" class="px-4 py-8 text-center text-slate-400">Sin trabajadores asignados</td></tr>`;
        document.getElementById(`${shift}-count`).textContent = `${people.length} asignados`;
    });
    document.getElementById('available-workers').textContent = `${active.length} trabajadores disponibles`;
    const supportCount = document.getElementById('schedule-support-count');
    if (supportCount) { const refs = getProductionSupportIdsForDate(new Date().toISOString().slice(0,10)); const supportNames = refs.map(id=>employees.find(e=>String(e.id)===String(id))).filter(Boolean); supportCount.textContent = `${supportNames.length} apoyos`; supportCount.title = supportNames.length ? `Apoyo: ${supportNames.map(e=>e.apellido).join(', ')}` : 'Sin personal de apoyo'; }
    renderScheduleSupportBanner();
}

// ============================================================
// PANEL EN VIVO DEL JEFE — 3 TURNOS
// ============================================================
function timeToMinutes(value) { if (!value) return 0; const parts=String(value).split(':').map(Number); return (parts[0]||0)*60+(parts[1]||0); }
function isNowInsideShift(start,end,nowMinutes) { const a=timeToMinutes(start),b=timeToMinutes(end); if(a===b)return true; return b>a?(nowMinutes>=a&&nowMinutes<b):(nowMinutes>=a||nowMinutes<b); }
function renderScheduleSupportBanner() {
    const banner=document.getElementById('schedule-support-banner');
    const list=document.getElementById('schedule-support-banner-list');
    const countEl=document.getElementById('schedule-support-banner-count');
    if(!banner||!list)return;
    const area=document.getElementById('schedule-area')?.value||'';
    const isProduction=String(area).toUpperCase()==='PRODUCCIÓN';
    banner.classList.toggle('hidden',!isProduction);
    if(!isProduction)return;
    const date=new Date().toISOString().slice(0,10);
    const ids=getProductionSupportIdsForDate(date);
    const people=ids.map(id=>employees.find(e=>String(e.id)===String(id))).filter(Boolean);
    if(countEl)countEl.textContent=String(people.length);
    list.innerHTML=people.length?people.map(e=>{ const entry=(productionSupport?.[date]||[]).find(item=>String(item?.workerId ?? item)===String(e.id)); const range=(entry?.start&&entry?.end)?` · ${escapeNormaHtml(entry.start)}–${escapeNormaHtml(entry.end)}`:''; return `<div class="schedule-support-person"><i class="fa-solid fa-user-plus"></i><div><strong>${escapeNormaHtml(e.apellido)}</strong><span>${escapeNormaHtml(e.nombre)} · Área original: ${escapeNormaHtml(e.area||'')}${range}</span></div></div>`; }).join(''):'<div class="support-empty">No hay personal de apoyo para hoy.</div>';
}

function renderLiveOperations() {
    const grid=document.getElementById('live-area-counters'), totalEl=document.getElementById('live-total-active'), clockEl=document.getElementById('live-clock'), dateEl=document.getElementById('live-date');
    if(!grid||!totalEl)return; const now=new Date();
    if(clockEl)clockEl.textContent=now.toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    if(dateEl)dateEl.textContent=now.toLocaleDateString('es-ES',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
    const areas=['PRODUCCIÓN','ETIQUETA','DESCONGELACIÓN','AHUMADOS']; const shifts=[{key:'turno1',label:'T1',time:'06:30–18:30'},{key:'turno2',label:'T2',time:'10:30–22:30'},{key:'turno3',label:'T3',time:'18:30–06:30'}]; let total=0;
    const refDate=(shift)=>{ const d=new Date(now); const m=now.getHours()*60+now.getMinutes(); if(shift==='turno3'&&m<1110)d.setDate(d.getDate()-1); return d; };
    const getSchedule=(date)=>{const week=Math.floor((date.getDate()-1)/7)+1, out={}; areas.forEach(area=>{const key=`${date.getFullYear()}-${date.getMonth()}-W${week}__${area}`;out[area]=shiftSchedule[key]||{turno1:[],turno2:[],turno3:[]};});return out;};
    const active=(emp,shift,ref)=>{const mk=`${ref.getFullYear()}-${ref.getMonth()}`,day=ref.getDate();if((attendanceData?.[mk]?.[emp.id]?.[day]||'')!=='X')return false;const cfg={turno1:{start:'06:30',end:'18:30'},turno2:{start:'10:30',end:'22:30'},turno3:{start:'18:30',end:'06:30'}}[shift];
    const hours=Number(workHoursData?.[mk]?.[emp.id]?.[day]||12);
    if(!cfg)return false; const nm=now.getHours()*60+now.getMinutes();
    if(!isNowInsideShift(cfg.start,cfg.end,nm))return false;
    if(hours<12){const st=timeToMinutes(cfg.start),elapsed=nm>=st?nm-st:nm+1440-st;if(elapsed>=hours*60)return false;}
    return true;};
    grid.innerHTML=areas.map(area=>{const counts=shifts.map(sh=>{const ref=refDate(sh.key), sc=getSchedule(ref)[area]||{}, ids=Array.isArray(sc[sh.key])?sc[sh.key]:[], count=ids.map(id=>employees.find(e=>e.id===id)).filter(Boolean).filter(emp=>emp.estado==='Activo'&&emp.area===area&&active(emp,sh.key,ref)).length; total+=count; return count;});const sum=counts.reduce((a,b)=>a+b,0);return `<article class="live-area-card ${sum?'has-active':''}"><div class="live-area-top"><div class="live-area-name">${area}</div><span class="live-area-indicator"></span></div><div class="live-area-count"><strong>${sum}</strong><span>activas ahora</span></div><div class="live-area-shifts">${shifts.map((sh,i)=>`<span class="live-shift-chip"><i class="fa-solid ${sh.icon}"></i><span>${sh.label} · ${sh.time}</span><b>${counts[i]}</b></span>`).join('')}</div></article>`;}).join('');
    totalEl.textContent=`${total} ${total===1?'persona activa':'personas activas'}`;
    const supportEl=document.getElementById('live-support-additional');
    if(supportEl){
        const today=now.toISOString().slice(0,10), minuteNow=now.getHours()*60+now.getMinutes();
        const activeSupport=(productionSupport?.[today]||[]).map(item=>{
            const e=employees.find(x=>String(x.id)===String(item?.workerId ?? item));
            if(!e||e.estado!=='Activo') return null;
            const st=item?.start||'', en=item?.end||'';
            const sm=st?timeToMinutes(st):null, em=en?timeToMinutes(en):null;
            const inWindow=sm!==null&&em!==null ? (sm<=em ? minuteNow>=sm&&minuteNow<em : minuteNow>=sm||minuteNow<em) : true;
            return inWindow ? {e,start:st,end:en} : null;
        }).filter(Boolean);
        supportEl.classList.toggle('hidden', activeSupport.length===0);
        supportEl.innerHTML=activeSupport.length ? `<div class="live-support-additional-head"><span><i class="fa-solid fa-user-plus"></i> Adicionales · Apoyo en Producción</span><strong>${activeSupport.length}</strong></div><div class="live-support-additional-list">${activeSupport.map(({e,start,end})=>`<div class="live-support-person"><div><strong>${escapeNormaHtml(e.apellido)}</strong><span>${escapeNormaHtml(e.nombre)} · Área original: ${escapeNormaHtml(e.area||'')} · ${escapeNormaHtml(start)}–${escapeNormaHtml(end)}</span></div><b>ADICIONAL</b></div>`).join('')}</div>` : '';
    }
}

function saveShiftRequirements() {
    const area = document.getElementById('schedule-area').value;
    const selection = getScheduleSelection();
    if (!area || !selection) { showNotification('Seleccione obligatoriamente el mes, la semana y el área del horario.', 'error'); return; }
    const key = getScheduleKey();
    const req = {
        turno1: Math.max(0, parseInt(document.getElementById('req-turno1').value) || 0),
        turno2: Math.max(0, parseInt(document.getElementById('req-turno2').value) || 0),
        turno3: Math.max(0, parseInt(document.getElementById('req-turno3').value) || 0)
    };
    if (!shiftSchedule[key]) shiftSchedule[key] = { turno1: [], turno2: [], turno3: [] };
    shiftSchedule[key].requirements = req;
    saveData();
    showNotification('Necesidades de personal guardadas para la semana seleccionada.', 'success');
}

function mixWorkersRandomly() {
    const area = document.getElementById('schedule-area').value;
    const selection = getScheduleSelection();
    if (!area || !selection) { showNotification('Seleccione obligatoriamente el mes, la semana y el área del horario.', 'error'); return; }
    saveShiftRequirements();
    const key = getScheduleKey();
    const req = shiftSchedule[key].requirements || {turno1:0,turno2:0,turno3:0};
    const active = shuffleArray(employees.filter(e => e.estado === 'Activo' && e.area === area));
    const total = req.turno1 + req.turno2 + req.turno3;
    if (total > active.length) {
        showNotification(`Se necesitan ${total} personas, pero solo hay ${active.length} disponibles en esta área.`, 'error');
        return;
    }
    shiftSchedule[key].turno1 = active.slice(0, req.turno1).map(e => e.id);
    shiftSchedule[key].turno2 = active.slice(req.turno1, req.turno1 + req.turno2).map(e => e.id);
    shiftSchedule[key].turno3 = active.slice(req.turno1 + req.turno2, total).map(e => e.id);
    saveData(); renderSchedule();
    showNotification(`Trabajadores mezclados y distribuidos aleatoriamente en ${formatScheduleWeekLabel(selection)}.`, 'success');
}

function loadScheduleRequirements() {
    const areaEl = document.getElementById('schedule-area');
    if (!areaEl) return;
    updateScheduleWeekOptions();
    const selection = getScheduleSelection();
    const key = getScheduleKey();
    const req = shiftSchedule?.[key]?.requirements || {turno1:0,turno2:0,turno3:0};
    document.getElementById('req-turno1').value = req.turno1;
    document.getElementById('req-turno2').value = req.turno2;
    document.getElementById('req-turno3').value = req.turno3;
    renderSchedule();
}

let draggedShiftWorker = null;

function startShiftDrag(event, empId, fromShift) {
    draggedShiftWorker = { empId, fromShift };
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', empId);
}

function setupShiftDropZones() {
    ['turno1','turno2','turno3'].forEach(shift => {
        const tbody = document.getElementById(`${shift}-tbody`);
        if (!tbody || tbody.dataset.dropReady === '1') return;
        tbody.dataset.dropReady = '1';

        tbody.addEventListener('dragover', e => {
            if (!draggedShiftWorker) return;
            e.preventDefault();
            e.stopPropagation();
            e.dataTransfer.dropEffect = 'move';
            tbody.classList.add('bg-primary-50');
        });

        tbody.addEventListener('dragenter', e => {
            if (!draggedShiftWorker) return;
            e.preventDefault();
            tbody.classList.add('bg-primary-50');
        });

        tbody.addEventListener('dragleave', e => {
            if (!tbody.contains(e.relatedTarget)) {
                tbody.classList.remove('bg-primary-50');
            }
        });

        tbody.addEventListener('drop', e => {
            e.preventDefault();
            e.stopPropagation();
            tbody.classList.remove('bg-primary-50');
            if (!draggedShiftWorker) return;
            const { empId, fromShift } = draggedShiftWorker;
            draggedShiftWorker = null;
            moveWorkerToShift(empId, fromShift, shift);
        });
    });
}

document.addEventListener('dragend', () => {
    draggedShiftWorker = null;
    ['turno1','turno2','turno3'].forEach(shift => {
        const tbody = document.getElementById(`${shift}-tbody`);
        if (tbody) tbody.classList.remove('bg-primary-50');
    });
});

function moveWorkerToShift(empId, fromShift, toShift) {
    if (fromShift === toShift) return;
    const key = getScheduleKey();
    if (!key) return;
    if (!shiftSchedule[key]) shiftSchedule[key] = {turno1:[],turno2:[],turno3:[],requirements:{turno1:0,turno2:0,turno3:0}};
    ['turno1','turno2','turno3'].forEach(s => {
        shiftSchedule[key][s] = (shiftSchedule[key][s] || []).filter(id => id !== empId);
    });
    shiftSchedule[key][toShift].push(empId);
    saveData();
    renderSchedule();
    showNotification('Trabajador movido manualmente de turno.', 'success');
}

function downloadScheduleCSV() {
    const area = document.getElementById('schedule-area').value;
    const selection = getScheduleSelection();
    const key = getScheduleKey();
    if (!area || !selection || !shiftSchedule[key]) {
        showNotification('Seleccione mes, semana y área y genere el horario antes de descargarlo.', 'error');
        return;
    }

    const schedule = shiftSchedule[key];
    const rows = [['Apellido','Nombre','Agencia','Área','Semana','Turno']];
    ['turno1','turno2','turno3'].forEach((shift, i) => {
        (schedule[shift] || []).forEach(id => {
            const e = employees.find(emp => emp.id === id);
            if (e) rows.push([e.apellido, e.nombre, e.agencia, e.area, formatScheduleWeekLabel(selection), `Turno ${i + 1}`]);
        });
    });
    if (rows.length === 1) {
        showNotification('No hay trabajadores asignados para descargar.', 'error');
        return;
    }
    const csv = rows.map(row => row.map(v => `"${String(v).replace(/"/g, '""')}"`).join(';')).join('\n');
    const blob = new Blob(["\ufeff" + csv], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `losos_bd_${selection.year}-${String(selection.month+1).padStart(2,'0')}_semana_${selection.week}_${area}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
}
