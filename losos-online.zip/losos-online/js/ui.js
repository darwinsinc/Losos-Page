/* ============================================================
   ŁOSOS SP · Utilidades de interfaz: pestañas, notificaciones, indicador de guardado, iconos y helpers de formato.
   ============================================================ */

function showAutoSaveIndicator(message) {
    const indicatorText = document.getElementById('autosave-text');
    const indicatorBox = document.getElementById('autosave-indicator');
    if (indicatorText && indicatorBox) {
        indicatorText.textContent = message || 'Guardando cambios...';
        indicatorBox.className = 'hidden sm:flex items-center gap-1.5 text-xs font-medium text-amber-600 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-lg';
        setTimeout(() => {
            indicatorText.textContent = message ? message : 'Cambios guardados';
            indicatorBox.className = 'hidden sm:flex items-center gap-1.5 text-xs font-medium text-emerald-600 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg';
        }, message ? 80 : 700);
    }
}

// Tab Switching
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.className = "tab-btn px-5 py-2.5 text-sm font-semibold rounded-xl transition-all duration-200 flex items-center gap-2 text-slate-600 hover:text-slate-900 hover:bg-white/50";
    });

    document.getElementById(`tab-${tabId}`).classList.add('active');
    const activeBtn = document.getElementById(`btn-${tabId}`);
    activeBtn.className = "tab-btn px-5 py-2.5 text-sm font-semibold rounded-xl transition-all duration-200 flex items-center gap-2 bg-white text-primary-700 shadow-sm border border-slate-200";

    if (tabId === 'registro') renderRegistroTable();
    if (tabId === 'asistencia') renderAttendanceTable();
    if (tabId === 'horarios') renderSchedule();
    if (tabId === 'historial') renderHistoryTable();
}
function escapeNormaHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}

// Usada al pintar la fila de cada trabajador en la tabla de Personal.
// Antes no estaba definida en ningún lugar del código: cada vez que se
// agregaba un trabajador y se intentaba dibujar su fila, el navegador
// lanzaba "escapeHtml is not defined" y la tabla se quedaba sin
// actualizar (por eso el trabajador "no aparecía" tras registrarlo).
function escapeHtml(value) {
    return escapeNormaHtml(value);
}
function formatTableDate(dateString) {
    if(!dateString) return '';
    const parts = dateString.split('-');
    if(parts.length !== 3) return dateString;
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

function showNotification(message, type = 'success') {
    const existingToast = document.getElementById('toast-notification');
    if (existingToast) existingToast.remove();

    const toast = document.createElement('div');
    toast.id = 'toast-notification';
    const bgColor = type === 'error' ? 'bg-red-600' : type === 'info' ? 'bg-slate-900' : 'bg-emerald-600';
    
    toast.className = `fixed bottom-5 right-5 z-50 ${bgColor} text-white px-5 py-3 rounded-xl shadow-2xl flex items-center gap-3 text-sm font-medium animate-bounce`;
    toast.innerHTML = `
                <i class="fa-solid fa-circle-info text-base"></i>
                <span>${message}</span>
            `;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
}
function toggleSchedulePanel(open) {
    const shell = document.getElementById('schedule-panel-shell');
    const launch = document.querySelector('.schedule-launch-section');
    if (!shell) return;
    shell.classList.toggle('hidden', !open);
    if (launch) launch.classList.toggle('hidden', open);
    if (open) {
        shell.scrollIntoView({ behavior: 'smooth', block: 'start' });
        if (typeof loadScheduleRequirements === 'function') loadScheduleRequirements();
    }
}

function applyIconMapping() {
    const map = {
        'language':'languages','clipboard-list':'clipboard-list','cloud-arrow-up':'cloud-upload','calendar-check':'calendar-check-2',
        'calendar':'calendar-days','filter':'filter','right-from-bracket':'log-out','shield-halved':'shield-check',
        'users':'users','users-slash':'user-round-x','pencil':'pencil','trash-can':'trash-2','plus':'plus',
        'minus':'minus','rotate-right':'rotate-ccw','file-export':'file-down','link':'link-2','user-check':'user-check',
        'search':'search','xmark':'x','edit':'pencil','pen':'pen-line','save':'save','download':'download','upload':'upload',
        'times':'x','check':'check','check-circle':'circle-check','exclamation-triangle':'triangle-alert','info-circle':'info',
        'bars':'menu','home':'house','cog':'settings','database':'database','file':'file','folder':'folder',
        'clock':'clock-3','chevron-down':'chevron-down','chevron-up':'chevron-up','chevron-left':'chevron-left',
        'chevron-right':'chevron-right','arrow-left':'arrow-left','arrow-right':'arrow-right','copy':'copy','print':'printer',
        'eye':'eye','eye-slash':'eye-off','lock':'lock','unlock':'unlock','sign-out-alt':'log-out','user':'user',
        'user-plus':'user-plus','chart-bar':'chart-column','chart-line':'chart-line','check-double':'check-check',
        'times-circle':'circle-x','question-circle':'circle-help','spinner':'loader-circle','sync':'refresh-cw',
        'sliders-h':'sliders-horizontal','list':'list','th':'grid-2x2','star':'star','heart':'heart','bookmark':'bookmark',
        'external-link-alt':'external-link','cloud-upload-alt':'cloud-upload','cloud-download-alt':'cloud-download',
        'box':'box','boxes':'boxes','tags':'tags','money-bill':'banknote','phone':'phone','envelope':'mail',
        'map-marker-alt':'map-pin','bell':'bell','bell-slash':'bell-off','globe':'globe-2','bars-staggered':'menu',
        'calendar-days':'calendar-days','clipboard':'clipboard','users-cog':'users-round'
    };
    document.querySelectorAll('i[class*="fa-"]').forEach(function(el){
        const classes=[...el.classList];
        const key=classes.map(c=>c.replace(/^fa-(?:solid|regular|brands|light|thin|duotone)-/, '').replace(/^fa-/,'')).find(k=>map[k]);
        if(!key || !window.lucide) return;
        el.setAttribute('data-lucide',map[key]);
        el.className='lucide-icon '+el.className.split(' ').filter(c=>!c.startsWith('fa-')).join(' ');
    });
    if(window.lucide) window.lucide.createIcons({attrs:{'stroke-width':1.9}});
}
